
    <section id="partner" class="home-section paddingbot-60">
      <div class="container marginbot-50">
        <div class="row">
          <div class="col-lg-12 col-lg-offset-2">
            <div class="wow lightSpeedIn" data-wow-delay="0.1s">
              <div class="section-heading text-center">
                <h2 class="h-bold">Our partner</h2>
                <p>Take charge of your health today with our specially designed health packages</p>
              </div>
            </div>
            <div class="divider-short"></div>
          </div>
        </div>
      </div>

      <div class="container">
        <div class="row ">
          <!-- <div> -->
          <div class="col-md-6">
            <div class="partner">
              <a href="#"><img src="img/dummy/dr_detox.png" alt=""  style="width:120px; height: 120px; opacity: 0.6;"/></a>
            </div>
          </div>
          <div class="col-md-6">
            <div class="partner">
              <a href="#"><img src="img/dummy/my_dietitian.png" style="width:190px;" alt="" /></a>
            </div>
          <!-- </div> -->
        </div>      </div>
    </section>
